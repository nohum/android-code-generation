package at.fhj.demoapp.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

public class EmptyService extends Service {
	
    public EmptyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    public static void startService(Context context) {
    	Intent intent = new Intent(context, EmptyService.class);
		context.startService(intent);
    }
    
    public static void stopService(Context context) {
    	Intent intent = new Intent(context, EmptyService.class);
		context.stopService(intent);
    }
}

