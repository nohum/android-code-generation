package at.fhj.demoapp.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import at.fhj.demoapp.R;

import at.fhj.demoapp.activity.FirstDemoActivity;

public class DemoReceiver extends BroadcastReceiver {
	
    public DemoReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("App", "DemoReceiver: received intent action = " + intent.getAction());
        
        FirstDemoActivity.openActivity(context);
    }
}

