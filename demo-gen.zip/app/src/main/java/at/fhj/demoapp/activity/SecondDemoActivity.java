package at.fhj.demoapp.activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

import at.fhj.demoapp.R;



public class SecondDemoActivity extends ActionBarActivity implements View.OnClickListener {
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_demo_activity);

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        
    }
    
    public static void openActivity(Context context) {
    	Intent intent = new Intent(context, SecondDemoActivity.class);
    	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
    }

    @Override
    public void onClick(View v) {
    }
}

