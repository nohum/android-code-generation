package at.fhj.demoapp.activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

import at.fhj.demoapp.R;

import android.widget.Button;
import android.widget.Toast;
import at.fhj.demoapp.activity.SecondDemoActivity;


public class FirstDemoActivity extends ActionBarActivity implements View.OnClickListener {
	
	private Button firstButton;
	private Button openSecondActivityButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_demo_activity);

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        
        firstButton = (Button) findViewById(R.id.first_button);
        firstButton.setOnClickListener(this);
        openSecondActivityButton = (Button) findViewById(R.id.open_second_activity_button);
        openSecondActivityButton.setOnClickListener(this);
    }
    
    public static void openActivity(Context context) {
    	Intent intent = new Intent(context, FirstDemoActivity.class);
    	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        if (v.equals(firstButton)) {
        	Toast.makeText(this, getString(R.string.first_demo_activity_first_button_toast), Toast.LENGTH_LONG).show();
        	
        	return;
        }
        if (v.equals(openSecondActivityButton)) {
        	Intent intent = new Intent(this, SecondDemoActivity.class);
        	startActivity(intent);
        	
        	return;
        }
    }
}

